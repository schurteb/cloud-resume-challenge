import React, { useState, useEffect } from 'react';
import Intro from "./components/Intro/";
import Crowdfunding from "./components/Crowdfunding";
import Footer from "./components/Footer";
import ConnectWalletButton from "./components/ConnectWalletButton";
import AppBar from '@mui/material/AppBar';

import { hooks as emptyHooks, empty } from './connectors/empty'
import { hooks as coinbaseWalletHooks, coinbaseWallet } from './connectors/coinbaseWallet'
import { hooks as metaMaskHooks, metaMask } from './connectors/metaMask'
import { hooks as networkHooks, network } from './connectors/network'
import { hooks as walletConnectHooks, walletConnect } from './connectors/walletConnect'
import { hooks as walletConnectV2Hooks, walletConnectV2 } from './connectors/walletConnectV2'

const connectors = [
  [empty, emptyHooks],
  [metaMask, metaMaskHooks],
  [walletConnect, walletConnectHooks],
  [walletConnectV2, walletConnectV2Hooks],
  [coinbaseWallet, coinbaseWalletHooks],
  [network, networkHooks],
]

function App() {
  const [hooks, setHooks] = useState(emptyHooks);

  /*return (
    <EthProvider>
      <div id="App">
        <AppBar id="AppBar">
          <ConnectWalletButton />
        </AppBar>
        
        <div className="container">
          <Intro />
          <hr />
          <Setup />
          <hr />
          <Demo />
          <hr />
          <VotingDemo />
          <hr />
          <Footer />
        </div>
      </div>
    </EthProvider>
  );*/

  return (
    <div id="App">
      <AppBar id="AppBar">
        <ConnectWalletButton hooks={hooks} setHooks={setHooks} />
      </AppBar>

      <div className="container">
        <Intro />
        <hr />
        <Crowdfunding />
        <hr />
        <Footer />
      </div>
    </div>
  );
}

export default App;
