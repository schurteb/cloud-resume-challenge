import { Web3ReactHooks } from "@web3-react/core";
import { useContext } from "react";
import Web3Context from "./Web3Context";

//@ts-ignore
const useWeb3: () => { state: { hooks: Web3ReactHooks } } = () => useContext(Web3Context);

export default useWeb3;
