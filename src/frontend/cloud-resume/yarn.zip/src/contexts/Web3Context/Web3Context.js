import { createContext } from "react";

const Web3Context = createContext();

export default Web3Context;
