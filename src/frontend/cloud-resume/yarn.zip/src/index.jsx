import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./styles.css";

import { useWeb3React, Web3ReactHooks, Web3ReactProvider } from '@web3-react/core'

import { hooks as emptyHooks, empty } from './connectors/empty'
import { hooks as coinbaseWalletHooks, coinbaseWallet } from './connectors/coinbaseWallet'
import { hooks as metaMaskHooks, metaMask } from './connectors/metaMask'
import { hooks as networkHooks, network } from './connectors/network'
import { hooks as walletConnectHooks, walletConnect } from './connectors/walletConnect'
import { hooks as walletConnectV2Hooks, walletConnectV2 } from './connectors/walletConnectV2'
import { getName } from './utils'

// Import missing dependency and inject it into window
import { Buffer } from 'buffer';
window.Buffer = window.Buffer || Buffer;

const connectors = [
  [empty, emptyHooks],
  [metaMask, metaMaskHooks],
  [walletConnect, walletConnectHooks],
  [walletConnectV2, walletConnectV2Hooks],
  [coinbaseWallet, coinbaseWalletHooks],
  [network, networkHooks],
]

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <Web3ReactProvider connectors={connectors}>
      <App />
    </Web3ReactProvider>
  </React.StrictMode>
);