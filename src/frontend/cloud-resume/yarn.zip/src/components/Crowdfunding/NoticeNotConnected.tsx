function NoticeNotConnected() {
  return (
    <p>
      ⚠️ Cannot find Wallet.
      Please connect your wallet.
    </p>
  );
}

export default NoticeNotConnected;
