import { useEffect, useState } from "react";
import { useWeb3React } from "@web3-react/core";
import ContractArtifact from "./ContractArtifact";
import { Contract, Transaction } from "ethers";
import { BigNumber } from "@ethersproject/bignumber";
import { formatEther, formatUnits, parseUnits } from "@ethersproject/units";

function ContractBtns(props: { contractArtifact: ContractArtifact, setValue: Function, setOwner: Function, setGoal: Function, setRaised: Function, setDeadline: Function, setGoalReached: Function }) {
  const { isActive, chainId, account, accounts, provider } = useWeb3React();
  const [inputValue, setInputValue] = useState("");
  const [ownerValue, setOwnerValue] = useState("");
  const [contributionValue, setContributionValue] = useState("");
  const [goalValue, setGoalValue] = useState("");
  const [deadlineValue, setDeadlineValue] = useState("");

  /*useEffect(() => {

  }, [props.contractArtifact]);*/

  const handleInputChange = e => {
    if (/^\d+$|^$/.test(e.target.value)) {
      setInputValue(e.target.value);
    }
  };

  const handleContributionInputChange = e => {
    if (/^\d+$|^$/.test(e.target.value)) {
      setContributionValue(e.target.value);
    }
  };

  const handleGoalInputChange = e => {
    if (/^\d+$|^$/.test(e.target.value)) {
      setGoalValue(e.target.value);
    }
  };

  const handleOwnerInputChange = e => {
    //if (/^\d+$|^$/.test(e.target.value)) {
    setOwnerValue(e.target.value);
    //}
  };

  const read = async () => {
    //const value = await contract.methods.read().call({ from: accounts[0] });
    //setValue(value);
  };

  const write = async e => {
    if (e.target.tagName === "INPUT") {
      return;
    }
    if (inputValue === "") {
      alert("Please enter a value to write.");
      return;
    }
    const newValue = parseInt(inputValue);
    //await contract.methods.write(newValue).send({ from: accounts[0] });
  };

  const readVariables = async () => {
    const signer = provider.getSigner(account);
    //const registry = SimpleStorage.deployed();
    //console.log(props.contractArtifact);
    const contract = new Contract(props.contractArtifact.networks[1337].address, props.contractArtifact.abi, provider);

    const tx: Transaction = await contract.owner().catch((e) => {
      console.log(e);
    })
      .then((result) => {
        //console.log(result);
        props.setOwner(result);
      });

    const tx2: Transaction = await contract.goal().catch((e) => {
      console.log(e);
    })
      .then((result: BigNumber) => {
        //console.log(`Ξ${formatEther(result)}`);
        props.setGoal(`Ξ${formatEther(result)}`);
      });

    const tx3: Transaction = await contract.raised().catch((e) => {
      console.log(e);
    })
      .then((result: BigNumber) => {
        //console.log(`Ξ${formatEther(result)}`);
        props.setRaised(`Ξ${formatEther(result)}`);
      });

    const tx4: Transaction = await contract.deadline().catch((e) => {
      console.log(e);
    })
      .then((result) => {
        //console.log(result.toNumber());
        props.setDeadline(result.toNumber());
      });

    const tx5: Transaction = await contract.goalReached().catch((e) => {
      console.log(e);
    })
      .then((result) => {
        //console.log(result);
        props.setGoalReached(`${result}`);
      });
  };

  const contribute = async (e) => {
    if (e.target.tagName === "INPUT") {
      return;
    }
    if (contributionValue === "") {
      alert("Please enter a value to write.");
      return;
    }

    const signer = provider.getSigner(account);
    //const registry = SimpleStorage.deployed();
    console.log(props.contractArtifact);
    const contract = new Contract(props.contractArtifact.networks[1337].address, props.contractArtifact.abi, signer);

    const tx: Transaction = await contract.contribute({ value: contributionValue }).catch((e) => {
      console.log(e);
    })
      .then((result) => {
        console.log(result);
      });
  };

  const withdrawContribution = async () => {
    const signer = provider.getSigner(account);
    //const registry = SimpleStorage.deployed();
    console.log(props.contractArtifact);
    const contract = new Contract(props.contractArtifact.networks[1337].address, props.contractArtifact.abi, signer);

    const tx: Transaction = await contract.withdrawContribution().catch((e) => {
      console.log(e);
    })
      .then((result) => {
        console.log(result);
      });
  };

  const releaseFunds = async () => {
    const signer = provider.getSigner(account);
    //const registry = SimpleStorage.deployed();
    console.log(props.contractArtifact);
    const contract = new Contract(props.contractArtifact.networks[1337].address, props.contractArtifact.abi, signer);

    const tx: Transaction = await contract.releaseFunds().catch((e) => {
      console.log(e);
    })
      .then((result) => {
        console.log(result);
      });
  };

  const updateGoal = async (e) => {
    if (e.target.tagName === "INPUT") {
      return;
    }
    if (goalValue === "") {
      alert("Please enter a value to write.");
      return;
    }

    const signer = provider.getSigner(account);
    //const registry = SimpleStorage.deployed();
    console.log(props.contractArtifact);
    const contract = new Contract(props.contractArtifact.networks[1337].address, props.contractArtifact.abi, signer);

    var bn = parseUnits(goalValue, "ether");

    console.log(bn);

    const tx: Transaction = await contract.updateGoal(bn.toHexString()).catch((e) => {
      console.log(e);
    })
      .then((result) => {
        console.log(result);
      });
  };

  const updateOwner = async (e) => {
    if (e.target.tagName === "INPUT") {
      return;
    }
    if (ownerValue === "") {
      alert("Please enter a value to write.");
      return;
    }

    const signer = provider.getSigner(account);
    //const registry = SimpleStorage.deployed();
    console.log(props.contractArtifact);
    const contract = new Contract(props.contractArtifact.networks[1337].address, props.contractArtifact.abi, signer);

    const tx: Transaction = await contract.updateOwner(ownerValue).catch((e) => {
      console.log(e);
    })
      .then((result) => {
        console.log(result);
      });
  };

  const cancelCampaign = async () => {
    const signer = provider.getSigner(account);
    //const registry = SimpleStorage.deployed();
    console.log(props.contractArtifact);
    const contract = new Contract(props.contractArtifact.networks[1337].address, props.contractArtifact.abi, signer);

    const tx: Transaction = await contract.cancelCampaign().catch((e) => {
      console.log(e);
    })
      .then((result) => {
        console.log(result);
      });
  };

  return (
    <div className="btns">

      <button onClick={readVariables}>
        read()
      </button>

      <div onClick={contribute} className="input-btn">
        contribute(<input
          type="text"
          placeholder="uint"
          value={contributionValue}
          onChange={handleContributionInputChange}
        />)
      </div>

      <div onClick={withdrawContribution} className="input-btn">
        withdrawContribution()
      </div>

      <div onClick={releaseFunds} className="input-btn">
        releaseFunds()
      </div>

      <div onClick={updateGoal} className="input-btn">
        updateGoal(<input
          type="text"
          placeholder="uint"
          value={goalValue}
          onChange={handleGoalInputChange}
        />)
      </div>

      <div onClick={updateOwner} className="input-btn">
        updateOwner(<input
          type="text"
          placeholder="address"
          value={ownerValue}
          onChange={handleOwnerInputChange}
        />)
      </div>

      <div onClick={cancelCampaign} className="input-btn">
        cancelCampaign()
      </div>

    </div>
  );
}

export default ContractBtns;
