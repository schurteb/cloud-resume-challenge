import { useEffect, useState } from "react";
//import useEth from "../../contexts/EthContext/useEth";
import Title from "./Title";
import Cta from "./Cta";
import ContractInfo from "./ContractInfo";
//import ContractBtns from "./ContractBtns";
import Desc from "./Desc";
import NoticeNoArtifact from "./NoticeNoArtifact";
import NoticeWrongNetwork from "./NoticeWrongNetwork";
import { useWeb3React } from "@web3-react/core";
import { Contract, ContractInterface, Transaction } from 'ethers';
import ContractBtns from "./ContractBtns";
import ContractArtifact from "./ContractArtifact";
import NoticeNotConnected from "./NoticeNotConnected";

function Demo() {
  const { isActive, chainId, account, accounts, provider } = useWeb3React();
  const [value, setValue] = useState("?");
  const [owner, setOwner] = useState("?");
  const [goal, setGoal] = useState("?");
  const [raised, setRaised] = useState("?");
  const [deadline, setDeadline] = useState("?");
  const [goalReached, setGoalReached] = useState("?");
  const [inputValue, setInputValue] = useState(0);
  const [contractArtifact, setContractArtifact] = useState<ContractArtifact>();

  const artifact = require("./../../contracts/Crowdfunding.json");

  useEffect(() => {
    const artifact = require("./../../contracts/Crowdfunding.json");

    if (artifact) {
      setContractArtifact(artifact);
    }
  }, []);

  const handleInputChange = e => {
    if (/^\d+$|^$/.test(e.target.value)) {
      setInputValue(e.target.value);
    }
  };

  return (
    <div className="demo">
      <Title />
      {/*
        !state.artifact ? <NoticeNoArtifact /> :
          !state.contract ? <NoticeWrongNetwork /> :
            demo
      */}

      {
        !isActive ? <NoticeNotConnected /> :
          !contractArtifact ? <NoticeNoArtifact /> :
            (
              <>
                <Cta />
                <div className="contract-container">
                  <ContractInfo
                    value={inputValue}
                    owner={owner}
                    goal={goal}
                    raised={raised}
                    deadline={deadline}
                    goalReached={goalReached}
                  />
                  {<ContractBtns
                    contractArtifact={contractArtifact}
                    setValue={setValue}
                    setOwner={setOwner}
                    setGoal={setGoal}
                    setRaised={setRaised}
                    setDeadline={setDeadline}
                    setGoalReached={setGoalReached}
                  />}
                </div>
                <Desc />
              </>
            )
      }

      {/*<div onClick={writeToContract} className="input-btn">
        write(<input
          type="text"
          placeholder="uint"
          value={inputValue}
          onChange={handleInputChange}
        />)
      </div>*/}
    </div>
  );
}

export default Demo;
