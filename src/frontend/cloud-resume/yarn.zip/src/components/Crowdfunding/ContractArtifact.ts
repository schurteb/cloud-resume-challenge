import { ContractInterface } from "ethers";

type ContractArtifact = {
    abi: ContractInterface,
    bytecode: string,
    contractName: string,
    deployedBytecode: string,
    metadata: string,
    networkType: string,
    networks: Map<Number, {
      address: string,
      events: Object,
      links: Object,
      transactionHash: string
    }>,
    source: string,
    sourceMap: string,
    sourcePath: string,
    updatedAt: string
  };

  export default ContractArtifact;