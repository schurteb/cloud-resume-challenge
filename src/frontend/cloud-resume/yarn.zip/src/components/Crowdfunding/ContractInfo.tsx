import { useRef, useEffect } from "react";

function ContractInfo({ owner, goal, raised, deadline, goalReached, value }) {
  const ownerEle = useRef(null);
  const goalEle = useRef(null);
  const raisedEle = useRef(null);
  const deadlineEle = useRef(null);
  const goalReachedEle = useRef(null);

  useEffect(() => {
    ownerEle.current?.classList.add("flash");
    const flash = setTimeout(() => {
      ownerEle.current?.classList.remove("flash");
    }, 300);
    return () => {
      clearTimeout(flash);
    };
  }, [owner]);

  useEffect(() => {
    goalEle.current?.classList.add("flash");
    const flash = setTimeout(() => {
      goalEle.current?.classList.remove("flash");
    }, 300);
    return () => {
      clearTimeout(flash);
    };
  }, [goal]);

  useEffect(() => {
    raisedEle.current?.classList.add("flash");
    const flash = setTimeout(() => {
      raisedEle.current?.classList.remove("flash");
    }, 300);
    return () => {
      clearTimeout(flash);
    };
  }, [raised]);

  useEffect(() => {
    deadlineEle.current?.classList.add("flash");
    const flash = setTimeout(() => {
      deadlineEle.current?.classList.remove("flash");
    }, 300);
    return () => {
      clearTimeout(flash);
    };
  }, [deadline]);

  useEffect(() => {
    goalReachedEle.current?.classList.add("flash");
    const flash = setTimeout(() => {
      goalReachedEle.current?.classList.remove("flash");
    }, 300);
    return () => {
      clearTimeout(flash);
    };
  }, [goalReached]);

  return (
    <code>
      {`contract Crowdfunding {
  address payable public owner = `}
  <span className="secondary-color" ref={ownerEle}>
  <strong>{owner}</strong>
</span>{`;
  uint public goal = `}
    <span className="secondary-color" ref={goalEle}>
    <strong>{goal}</strong>
  </span>{`;
  uint public raised = `}
    <span className="secondary-color" ref={raisedEle}>
    <strong>{raised}</strong>
  </span>{`;
  uint public deadline = `}
    <span className="secondary-color" ref={deadlineEle}>
    <strong>{deadline}</strong>
  </span>{`;
  bool public goalReached = `}
    <span className="secondary-color" ref={goalReachedEle}>
    <strong>{goalReached}</strong>
  </span>{`;

  address[] public contributors;
  mapping(address => bool) private _exists;
  mapping(address => uint) public contributions;

  modifier onlyOwner {
    require(msg.sender == owner, "Only owner can perform this action.");
    _;
  }

  modifier onlyBeforeDeadline {
    require(block.timestamp < deadline, "The deadline has passed.");
    _;
  }

  modifier onlyAfterDeadline {
    require(block.timestamp >= deadline, "The deadline has not yet passed.");
    _;
  }

  constructor(address payable _owner, uint _goal, uint _deadline) {
    owner = _owner;
    goal = _goal;
    deadline = block.timestamp + _deadline;
    goalReached = false;
  }

  function contribute() public payable onlyBeforeDeadline {
    require(msg.value > 0, "Contribution must be greater than 0");

    if (!_exists[msg.sender]) {
      contributors.push(msg.sender);
    }

    contributions[msg.sender] += msg.value;
    raised += msg.value;

    if (address(this).balance >= goal) {
      goalReached = true;
    }
  }

  function withdrawContribution() public onlyAfterDeadline {
    require(contributions[msg.sender] > 0, "You have no contributions to withdraw.");
    require(!goalReached, "The goal has been reached.");
      
    uint amount = contributions[msg.sender];
    contributions[msg.sender] = 0;
    payable(msg.sender).transfer(amount);
  }

  function releaseFunds() public onlyOwner {
    require(goalReached, "Funding goal not yet reached");

    owner.transfer(address(this).balance);
  }

  function updateGoal(uint _newGoal) public onlyOwner {
    goal = _newGoal;
  }

  function updateOwner(address payable _newOwner) public onlyOwner {
    owner = _newOwner;
  }

  function cancelCampaign() public onlyOwner {
    // We know the length of the array
    uint arrayLength = contributors.length;
      
    for (uint i = 0; i < arrayLength; i++) {
      address contributor = contributors[i];
      uint amount = contributions[contributor];

      if (amount > 0) {
        contributions[contributor] = 0;
        payable(contributor).transfer(amount);
      }
    }

    selfdestruct(owner);
  }
}`}
    </code>
  );
}

export default ContractInfo;
