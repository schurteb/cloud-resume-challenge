import React, { useState, useEffect } from 'react';
import Web3 from 'web3';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';

import { useWeb3React, Web3ReactHooks, Web3ReactProvider } from '@web3-react/core'

import { hooks as emptyHooks, empty } from '../connectors/empty';
import { hooks as coinbaseWalletHooks, coinbaseWallet } from '../connectors/coinbaseWallet'
import { hooks as metaMaskHooks, metaMask } from '../connectors/metaMask'
import { hooks as networkHooks, network } from '../connectors/network'
import { hooks as walletConnectHooks, walletConnect } from '../connectors/walletConnect'
import { hooks as walletConnectV2Hooks, walletConnectV2 } from '../connectors/walletConnectV2'
import { getName, useBalances } from '../utils'
import { Web3Provider } from '@ethersproject/providers';
import { BigNumber } from '@ethersproject/bignumber';
import { formatEther } from '@ethersproject/units'
import { isBigNumberish } from '@ethersproject/bignumber/lib/bignumber';

//var INFURA_KEY = "1d86c4bb7cd949f89bdebcaa82583974";

const connectors = [
    [empty, emptyHooks],
    [metaMask, metaMaskHooks],
    [walletConnect, walletConnectHooks],
    [walletConnectV2, walletConnectV2Hooks],
    [coinbaseWallet, coinbaseWalletHooks],
    [network, networkHooks],
    //[trustWallet, trustWalletHooks],
];

const modalStyle = {
    //position: 'absolute' as 'absolute',
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
};

//function ConnectWalletButton(props: {hooks: Web3ReactHooks, setHooks: (Web3ReactHooks) => {}}) {
function ConnectWalletButton(props) {
    //const { state, initFromButton, disconnectFromButton } = useEth();
    //const { state /*initFromButton, disconnectFromButton*/ } = useWeb3();
    const [connected, setConnected] = useState(false);
    const [address, setAddress] = useState('');
    const [balance, setBalance] = useState('');
    const [modalOpen, setModalOpen] = useState(false);
    //const [hooks, setHooks] = useState(emptyHooks);

    //const web3React = useWeb3React();

    //console.log(web3React.chainId, web3React.account, web3React.isActive);
    const { isActive, chainId, account, accounts, provider } = useWeb3React();

    provider?.getBalance(
        account,
        "latest"
    )
    .catch((e) => {
        console.log(e);
    })
    .then((value: void | BigNumber) => {
        if (isBigNumberish(value)){
            //@ts-ignore
            console.log(formatEther(value));
        }
    });

    const handleModalOpen = () => {
        setModalOpen(true);
    };

    const handleModalClose = () => {
        setModalOpen(false);
    };

    const connectMetaMask = async () => {
        await metaMask
            //.activate(31337)
            .activate(1337) //Truffle
            //.activate(5777) //Ganache
            .catch((e) => {
                console.log(`activate error ${e.message}`)
            })
            .then(() => {
                //setConnected(isActive);
                //setAddress(account);
                props.setHooks(metaMaskHooks);
                //setModalOpen(false);
            });
    };

    const connectCoinbaseWallet = async () => {
        await coinbaseWallet
            //.activate(31337)
            .activate(1337) //Truffle
            //.activate(5777) //Ganache
            .catch((e) => {
                console.log(`activate error ${e.message}`)
            })
            .then(() => {
                //setConnected(isActive);
                //setAddress(account);
                props.setHooks(coinbaseWalletHooks);
                //setModalOpen(false);
            })
    };

    const connectWalletConnect = async () => {
        await walletConnect
            //.activate(31337)
            .activate(1) //Ethereum Mainnet
            //.activate(1337) //Truffle
            //.activate(5777) //Ganache
            .catch((e) => {
                console.log(`activate error ${e.message}`)
            })
            .then(() => {
                //setConnected(isActive);
                //setAddress(account);
                props.setHooks(walletConnectHooks);
                //setModalOpen(false);
            })
    };

    const connectWalletConnectV2 = async () => {
        await walletConnectV2
            //.activate(31337)
            .activate(1) //Ethereum Mainnet
            //.activate(1337) //Truffle
            //.activate(5777) //Ganache
            .catch((e) => {
                console.log(`activate error ${e.message}`)
            })
            .then(() => {
                //setConnected(isActive);
                //setAddress(account);
                props.setHooks(walletConnectV2Hooks);
                //setModalOpen(false);
            })
    };

    const disconnect = async () => {
        //setConnected(false);
        //setAddress('');
        //setBalance('');
        props.setHooks(emptyHooks);
    };

    return (
        <>
            {!isActive ? (

                <>
                    <Button variant="contained" onClick={handleModalOpen}>Connect Wallet</Button>
                    <Modal
                        open={modalOpen}
                        onClose={handleModalClose}
                        aria-labelledby="modal-modal-title"
                        aria-describedby="modal-modal-description"
                    >
                        <Box sx={modalStyle}>
                            <Typography id="modal-modal-title" variant="h6" component="h2">
                                Text in a modal
                            </Typography>
                            <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                                Duis mollis, est non commodo luctus, nisi erat porttitor ligula.
                            </Typography>
                            <Button variant="contained" onClick={connectMetaMask}>Metamask</Button>
                            {/*<Button variant="contained" onClick={connectCoinbaseWallet}>Coinbase Wallet</Button>*/}
                            <Button variant="contained" onClick={connectWalletConnect}>WalletConnect</Button>
                            {/*<Button variant="contained" onClick={connectWalletConnectV2}>WalletConnectV2</Button>*/}
                            {/*<Button variant="contained" onClick={connectTrustWallet}>Trust Wallet</Button>*/}
                        </Box>
                    </Modal>
                </>
            ) : (
                <>
                    <Button variant="contained" onClick={disconnect}>Disconnect</Button>
                    <div>Connection Status: {isActive.toString()} | Account: {account} | Network ID: {chainId} | Balance: {/*balances?.[0] ? ` (Ξ${formatEther(balances[0])})` : null*/}</div>
                </>
            )}
        </>
    );
}

export default ConnectWalletButton;