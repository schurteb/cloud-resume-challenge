import { useState } from "react";
//import useEth from "../../contexts/EthContext/useEth";
import Title from "./Title";
import Cta from "./Cta";
import ContractInfo from "./Contract";
//import ContractBtns from "./ContractBtns";
import Desc from "./Desc";
import NoticeNoArtifact from "./NoticeNoArtifact";
import NoticeWrongNetwork from "./NoticeWrongNetwork";
import { useWeb3React } from "@web3-react/core";
import { Contract } from 'ethers';

function Demo() {
  //const { state } = useEth();
  const { isActive, chainId, account, accounts, provider } = useWeb3React();
  const [value, setValue] = useState("?");
  const [inputValue, setInputValue] = useState(0);

  const artifact = require("./../../contracts/SimpleStorage.json");

  const handleInputChange = e => {
    if (/^\d+$|^$/.test(e.target.value)) {
      setInputValue(e.target.value);
    }
  };

  const writeToContract = () => {
    const signer = provider.getSigner(account);
    //const registry = SimpleStorage.deployed();
    console.log(artifact);
    const contract = new Contract(artifact.networks[5777].address, artifact.abi, signer);

    const tx = contract.write(inputValue).catch((e) => {
      console.log(e);
    })
    .then((result) => {
      console.log(result);
    });
  };

  const demo =
    <>
      <Cta />
      <div className="contract-container">
        <ContractInfo value={inputValue} />
        {/*<ContractBtns setValue={setValue} writeToContract={writeToContract} />*/}
      </div>
      <Desc />
    </>;

  return (
    <div className="demo">
      <Title />
      {/*
        !state.artifact ? <NoticeNoArtifact /> :
          !state.contract ? <NoticeWrongNetwork /> :
            demo
      */}

      <div onClick={writeToContract} className="input-btn">
        write(<input
          type="text"
          placeholder="uint"
          value={inputValue}
          onChange={handleInputChange}
        />)
      </div>
    </div>
  );
}

export default Demo;
