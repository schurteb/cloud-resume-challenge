import { useState } from "react";
import useEth from "../../contexts/EthContext/useEth";

function ContractBtns({ setValue }) {
  const { state: { contract, tokenContract, accounts } } = useEth();
  const [mintInputValue, setMintInputValue] = useState("");
  const [inputValue, setInputValue] = useState("");

  const handleMintInputChange = e => {
    if (/^\d+$|^$/.test(e.target.value)) {
      setMintInputValue(e.target.value);
    }
  };

  const handleInputChange = e => {
    if (/^\d+$|^$/.test(e.target.value)) {
      setInputValue(e.target.value);
    }
  };

  const read = async () => {
    const value = await tokenContract.methods.balanceOf(accounts[0]).call({ from: accounts[0] });
    setValue(value);
  };

  const mintTo = async e => {
    if (e.target.tagName === "INPUT") {
      return;
    }
    if (mintInputValue === "") {
      alert("Please enter a value to mint.");
      return;
    }
    const newValue = parseInt(mintInputValue);
    await tokenContract.methods.mintTo(accounts[0], newValue).send({ from: accounts[0] });
  };

  const write = async e => {
    if (e.target.tagName === "INPUT") {
      return;
    }
    if (inputValue === "") {
      alert("Please enter a value to write.");
      return;
    }
    const newValue = parseInt(inputValue);
    await contract.methods.write(newValue).send({ from: accounts[0] });
  };

  return (
    <div className="btns">

      <button onClick={read}>
        read()
      </button>

      <div onClick={mintTo} className="input-btn">
        mintTao(<input
          type="text"
          placeholder="uint"
          value={mintInputValue}
          onChange={handleMintInputChange}
        />)
      </div>

      <div onClick={write} className="input-btn">
        write(<input
          type="text"
          placeholder="uint"
          value={inputValue}
          onChange={handleInputChange}
        />)
      </div>

    </div>
  );
}

export default ContractBtns;
