function Cta() {
  return (
    <p>
      Try changing&nbsp;
      <span className="code">value</span>
      &nbsp;in&nbsp;
      <span className="code">MyVotingToken</span>.
    </p>
  );
}

export default Cta;
