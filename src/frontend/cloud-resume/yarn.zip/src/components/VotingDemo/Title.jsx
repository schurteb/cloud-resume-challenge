function Title() {
  return <h2>See voting demo in action</h2>;
}

export default Title;
